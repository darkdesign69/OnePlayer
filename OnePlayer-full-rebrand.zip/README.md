# One Player

One Player is a video and music player for Android, built on the libmpv library.

## Build

Push the project to GitHub. The included workflow builds the debug APK on every push.
You can also build locally with `./gradlew assembleStandardDebug`.

## License

Released under the Apache License 2.0. See [LICENSE](LICENSE).
