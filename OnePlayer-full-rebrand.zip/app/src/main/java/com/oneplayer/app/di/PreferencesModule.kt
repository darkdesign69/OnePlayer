package com.oneplayer.app.di

import com.oneplayer.app.database.OnePlayerDatabase
import com.oneplayer.app.preferences.AdvancedPreferences
import com.oneplayer.app.preferences.AppearancePreferences
import com.oneplayer.app.preferences.AudioPreferences
import com.oneplayer.app.preferences.BrowserPreferences
import com.oneplayer.app.preferences.DecoderPreferences
import com.oneplayer.app.preferences.FoldersPreferences
import com.oneplayer.app.preferences.GesturePreferences
import com.oneplayer.app.preferences.PlayerPreferences
import com.oneplayer.app.preferences.SettingsManager
import com.oneplayer.app.preferences.SubtitlesPreferences
import com.oneplayer.app.preferences.preference.AndroidPreferenceStore
import com.oneplayer.app.preferences.preference.PreferenceStore
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

val PreferencesModule =
  module {
    single { AndroidPreferenceStore(androidContext()) }.bind(PreferenceStore::class)

    single { AppearancePreferences(get()) }
    singleOf(::PlayerPreferences)
    singleOf(::GesturePreferences)
    singleOf(::DecoderPreferences)
    singleOf(::SubtitlesPreferences)
    singleOf(::AudioPreferences)
    singleOf(::AdvancedPreferences)
    single { BrowserPreferences(get(), androidContext()) }
    singleOf(::FoldersPreferences)
    singleOf(::SettingsManager)
  }
