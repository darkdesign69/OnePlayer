package com.oneplayer.app.preferences

enum class SeekbarStyle {
    Standard,
    Wavy,
    Thick,
}
