package com.oneplayer.app.ui.theme

import androidx.compose.material3.Typography

// Use system default typography
val AppTypography = Typography()
