package com.oneplayer.app.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.oneplayer.app.database.converters.NetworkProtocolConverter
import com.oneplayer.app.database.dao.NetworkConnectionDao
import com.oneplayer.app.database.dao.PlaybackStateDao
import com.oneplayer.app.database.dao.PlaylistDao
import com.oneplayer.app.database.dao.RecentlyPlayedDao
import com.oneplayer.app.database.dao.VideoMetadataDao
import com.oneplayer.app.database.entities.PlaybackStateEntity
import com.oneplayer.app.database.entities.PlaylistEntity
import com.oneplayer.app.database.entities.PlaylistItemEntity
import com.oneplayer.app.database.entities.RecentlyPlayedEntity
import com.oneplayer.app.database.entities.VideoMetadataEntity
import com.oneplayer.app.domain.network.NetworkConnection

@Database(
  entities = [
    PlaybackStateEntity::class,
    RecentlyPlayedEntity::class,
    VideoMetadataEntity::class,
    NetworkConnection::class,
    PlaylistEntity::class,
    PlaylistItemEntity::class,
  ],
  version = 8,
  exportSchema = true,
)
@TypeConverters(NetworkProtocolConverter::class)
abstract class OnePlayerDatabase : RoomDatabase() {
  abstract fun videoDataDao(): PlaybackStateDao

  abstract fun recentlyPlayedDao(): RecentlyPlayedDao

  abstract fun videoMetadataDao(): VideoMetadataDao

  abstract fun networkConnectionDao(): NetworkConnectionDao

  abstract fun playlistDao(): PlaylistDao
}
