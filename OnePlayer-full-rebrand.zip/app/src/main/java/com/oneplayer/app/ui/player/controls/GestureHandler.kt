package com.oneplayer.app.ui.player.controls

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `is`.xyz.mpv.MPVLib
import com.oneplayer.app.preferences.AudioPreferences
import com.oneplayer.app.preferences.GesturePreferences
import com.oneplayer.app.preferences.PlayerPreferences
import com.oneplayer.app.preferences.preference.collectAsState
import com.oneplayer.app.presentation.components.LeftSideOvalShape
import com.oneplayer.app.presentation.components.RightSideOvalShape
import com.oneplayer.app.ui.player.Panels
import com.oneplayer.app.ui.player.PlayerUpdates
import com.oneplayer.app.ui.player.PlayerViewModel
import com.oneplayer.app.ui.player.SingleActionGesture
import com.oneplayer.app.ui.theme.playerRippleConfiguration
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.compose.koinInject
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

@Suppress("CyclomaticComplexMethod", "MultipleEmitters")
@Composable
fun GestureHandler(
  viewModel: PlayerViewModel,
  interactionSource: MutableInteractionSource,
  modifier: Modifier = Modifier,
) {
  val playerPreferences = koinInject<PlayerPreferences>()
  val audioPreferences = koinInject<AudioPreferences>()
  val gesturePreferences = koinInject<GesturePreferences>()
  val panelShown by viewModel.panelShown.collectAsState()
  val allowGesturesInPanels by playerPreferences.allowGesturesInPanels.collectAsState()
  val paused by MPVLib.propBoolean["pause"].collectAsState()
  val duration by MPVLib.propInt["duration"].collectAsState()
  val position by MPVLib.propInt["time-pos"].collectAsState()
  val playbackSpeed by MPVLib.propFloat["speed"].collectAsState()
  val controlsShown by viewModel.controlsShown.collectAsState()
  val areControlsLocked by viewModel.areControlsLocked.collectAsState()
  val seekAmount by viewModel.doubleTapSeekAmount.collectAsState()
  val isSeekingForwards by viewModel.isSeekingForwards.collectAsState()
  val useSingleTapForCenter by gesturePreferences.useSingleTapForCenter.collectAsState()
  val doubleTapSeekAreaWidth by gesturePreferences.doubleTapSeekAreaWidth.collectAsState()
  var isDoubleTapSeeking by remember { mutableStateOf(false) }
  LaunchedEffect(seekAmount) {
    delay(800)
    isDoubleTapSeeking = false
    viewModel.updateSeekAmount(0)
    viewModel.updateSeekText(null)
    delay(100)
    viewModel.hideSeekBar()
  }
  val multipleSpeedGesture by playerPreferences.holdForMultipleSpeed.collectAsState()
  val showDynamicSpeedOverlay by playerPreferences.showDynamicSpeedOverlay.collectAsState()
  val brightnessGesture by playerPreferences.brightnessGesture.collectAsState()
  val volumeGesture by playerPreferences.volumeGesture.collectAsState()
  val swapVolumeAndBrightness by playerPreferences.swapVolumeAndBrightness.collectAsState()
  val pinchToZoomGesture by playerPreferences.pinchToZoomGesture.collectAsState()
  val panAndZoomEnabled by playerPreferences.panAndZoomEnabled.collectAsState()
  val horizontalSwipeToSeek by playerPreferences.horizontalSwipeToSeek.collectAsState()
  val horizontalSwipeSensitivity by playerPreferences.horizontalSwipeSensitivity.collectAsState()
  var isLongPressing by remember { mutableStateOf(false) }
  var isDynamicSpeedControlActive by remember { mutableStateOf(false) }
  var dynamicSpeedStartX by remember { mutableStateOf(0f) }
  var dynamicSpeedStartValue by remember { mutableStateOf(2f) }
  var lastAppliedSpeed by remember { mutableStateOf(2f) }
  var hasSwipedEnough by remember { mutableStateOf(false) }
  var longPressTriggeredDuringTouch by remember { mutableStateOf(false) }
  var isVerticalGestureActive by remember { mutableStateOf(false) }
  val currentVolume by viewModel.currentVolume.collectAsState()
  val currentMPVVolume by MPVLib.propInt["volume"].collectAsState()
  val currentBrightness by viewModel.currentBrightness.collectAsState()
  val volumeBoostingCap = audioPreferences.volumeBoostCap.get()
  val haptics = LocalHapticFeedback.current
  val coroutineScope = rememberCoroutineScope()

  // Isolated double-tap state tracking
  var tapCount by remember { mutableStateOf(0) }
  var lastTapTime by remember { mutableStateOf(0L) }
  var lastTapPosition by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
  var lastTapRegion by remember { mutableStateOf<String?>(null) }
  var pendingSingleTapRegion by remember { mutableStateOf<String?>(null) }
  var pendingSingleTapPosition by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
  val doubleTapTimeout = 250L
  val multiTapContinueWindow = 650L

  // Multi-tap seeking state
  var lastSeekRegion by remember { mutableStateOf<String?>(null) }
  var lastSeekTime by remember { mutableStateOf<Long?>(null) }

  // Auto-reset tap count on timeout and execute single tap if no double tap detected
  LaunchedEffect(tapCount, longPressTriggeredDuringTouch) {
    if (tapCount == 1 && pendingSingleTapRegion != null) {
      delay(doubleTapTimeout)
      // Timeout occurred, execute single tap action only if not double-tap seeking and not triggered by long press
      if (tapCount == 1 && pendingSingleTapRegion != null && !isDoubleTapSeeking && !longPressTriggeredDuringTouch) {
        val region = pendingSingleTapRegion!!
        val isCenterTap = region == "center"
        if (useSingleTapForCenter && isCenterTap) {
          viewModel.handleCenterSingleTap()
        } else {
          if (panelShown != Panels.None && !allowGesturesInPanels) {
            viewModel.panelShown.update { Panels.None }
          }
          if (controlsShown) {
            viewModel.hideControls()
          } else {
            viewModel.showControls()
          }
        }
        pendingSingleTapRegion = null
        pendingSingleTapPosition = null
      }
      tapCount = 0
      lastTapRegion = null
      if (!isDoubleTapSeeking) {
        isDoubleTapSeeking = false
        viewModel.updateSeekAmount(0)
      }
    }
  }

  // Reset double-tap seek state when seeking stops
  LaunchedEffect(seekAmount) {
    if (seekAmount == 0) {
      delay(100)
      isDoubleTapSeeking = false
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 48.dp, vertical = 48.dp)
      .pointerInput(areControlsLocked, doubleTapSeekAreaWidth, gesturePreferences, isVerticalGestureActive) {
        // Isolated double-tap detection that doesn't interfere with other gestures
        if (isVerticalGestureActive) return@pointerInput
        awaitEachGesture {
          val down = awaitFirstDown(requireUnconsumed = false)
          val downPosition = down.position
          val downTime = System.currentTimeMillis()

          // Calculate regions
          val seekAreaFraction = doubleTapSeekAreaWidth / 100f
          val leftBoundary = size.width * seekAreaFraction
          val rightBoundary = size.width * (1f - seekAreaFraction)
          val region = when {
            downPosition.x > rightBoundary -> "right"
            downPosition.x < leftBoundary -> "left"
            else -> "center"
          }

          // Track for potential drag
          var isDrag = false
          var wasConsumedByTapGesture = false

          do {
            val event = awaitPointerEvent()
            val pointer = event.changes.firstOrNull { it.id == down.id } ?: break

            // Check if this is a drag (not a tap)
            val distance = sqrt(
              (pointer.position.x - downPosition.x) * (pointer.position.x - downPosition.x) +
              (pointer.position.y - downPosition.y) * (pointer.position.y - downPosition.y)
            )

            if (distance > 10f) {
              isDrag = true
              // Don't consume - let other pointer inputs handle drag gestures
            }

            if (!pointer.pressed) {
              // Pointer lifted - this is a tap if it wasn't a drag
              if (!isDrag && !wasConsumedByTapGesture) {
                val timeSinceLastTap = downTime - lastTapTime
                val positionChange = sqrt(
                  (downPosition.x - lastTapPosition.x) * (downPosition.x - lastTapPosition.x) +
                  (downPosition.y - lastTapPosition.y) * (downPosition.y - lastTapPosition.y)
                )

                // Check if this is a continuation of multi-tap sequence
                val isMultiTapContinuation =
                  lastTapRegion == region &&
                  timeSinceLastTap < multiTapContinueWindow &&
                  positionChange < 100f &&
                  tapCount >= 2 &&
                  isDoubleTapSeeking

                // Check if this is a valid double-tap
                val isDoubleTap =
                  timeSinceLastTap < doubleTapTimeout &&
                  lastTapRegion == region &&
                  positionChange < 100f &&
                  tapCount == 1

                if (isDoubleTap && !areControlsLocked) {
                  // Valid double-tap detected
                  tapCount = 2
                  lastTapTime = downTime
                  lastTapPosition = downPosition
                  pendingSingleTapRegion = null // Cancel pending single tap
                  pendingSingleTapPosition = null
                  wasConsumedByTapGesture = true
                  pointer.consume()

                  when (region) {
                    "right" -> {
                      val rightGesture = gesturePreferences.rightSingleActionGesture.get()
                      if (rightGesture == SingleActionGesture.Seek) {
                        isDoubleTapSeeking = true
                        lastSeekRegion = "right"
                        lastSeekTime = System.currentTimeMillis()
                        if (!isSeekingForwards) viewModel.updateSeekAmount(0)
                      }
                      viewModel.handleRightDoubleTap()
                    }
                    "left" -> {
                      val leftGesture = gesturePreferences.leftSingleActionGesture.get()
                      if (leftGesture == SingleActionGesture.Seek) {
                        isDoubleTapSeeking = true
                        lastSeekRegion = "left"
                        lastSeekTime = System.currentTimeMillis()
                        if (isSeekingForwards) viewModel.updateSeekAmount(0)
                      }
                      viewModel.handleLeftDoubleTap()
                    }
                    "center" -> {
                      viewModel.handleCenterDoubleTap()
                    }
                  }
                } else if (isMultiTapContinuation && isDoubleTapSeeking) {
                  // Continue multi-tap seeking
                  tapCount++
                  wasConsumedByTapGesture = true
                  pointer.consume()
                  lastSeekTime = System.currentTimeMillis()
                  lastTapTime = downTime
                  lastTapPosition = downPosition

                  when (region) {
                    "right" -> {
                      val rightGesture = gesturePreferences.rightSingleActionGesture.get()
                      if (rightGesture == SingleActionGesture.Seek) {
                        if (!isSeekingForwards) viewModel.updateSeekAmount(0)
                      }
                      viewModel.handleRightDoubleTap()
                    }
                    "left" -> {
                      val leftGesture = gesturePreferences.leftSingleActionGesture.get()
                      if (leftGesture == SingleActionGesture.Seek) {
                        if (isSeekingForwards) viewModel.updateSeekAmount(0)
                      }
                      viewModel.handleLeftDoubleTap()
                    }
                    "center" -> {
                      viewModel.handleCenterDoubleTap()
                    }
                  }
                } else if (tapCount == 0 || timeSinceLastTap >= doubleTapTimeout) {
                  // Single tap or timed out - start new tap sequence
                  tapCount = 1
                  lastTapTime = downTime
                  lastTapPosition = downPosition
                  lastTapRegion = region
                  pendingSingleTapRegion = region
                  pendingSingleTapPosition = downPosition
                  wasConsumedByTapGesture = true
                  pointer.consume()
                  // Don't execute single tap action yet - wait to see if second tap comes
                }
              }
              break
            }
          } while (event.changes.any { it.pressed })
        }
      }
      .pointerInput(areControlsLocked, multipleSpeedGesture, brightnessGesture, volumeGesture) {
        if ((!brightnessGesture && !volumeGesture && multipleSpeedGesture <= 0f) || areControlsLocked) return@pointerInput

        awaitEachGesture {
          val down = awaitFirstDown(requireUnconsumed = false)
          val startPosition = down.position

          // Reset long press tracking at the start of each gesture
          longPressTriggeredDuringTouch = false

          // State for vertical gestures (volume/brightness)
          var startingY = 0f
          var mpvVolumeStartingY = 0f
          var originalVolume = currentVolume
          var originalMPVVolume = currentMPVVolume
          var originalBrightness = currentBrightness
          var lastVolumeValue = currentVolume
          var lastMPVVolumeValue = currentMPVVolume ?: 100
          var lastBrightnessValue = currentBrightness
          // A swipe of about 25% of the screen height covers the whole 0..100 range
          val gestureRangePx = (size.height * 0.25f).coerceAtLeast(300f)
          val brightnessGestureSens = 1f / gestureRangePx
          val volumeLevelPerPx = 100f / gestureRangePx
          var volumeStartLevel = 0f

          // Original speed for long press
          var originalSpeed = playbackSpeed ?: 1f

          // Track long press separately
          var longPressTriggered = false
          val longPressDelay = 500L
          var longPressJob = coroutineScope.launch {
            delay(longPressDelay)
            if (!longPressTriggered && paused == false) {
              val distance = sqrt(
                (down.position.x - startPosition.x) * (down.position.x - startPosition.x) +
                (down.position.y - startPosition.y) * (down.position.y - startPosition.y)
              )
              // Only trigger if still within tap threshold
              if (distance < 10f && multipleSpeedGesture > 0f) {
                longPressTriggered = true
                isLongPressing = true
                longPressTriggeredDuringTouch = true
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                originalSpeed = playbackSpeed ?: 1f
                // Ramp speed up incrementally to avoid audio filter stutter
                val startSpeed = originalSpeed
                val targetSpeed = multipleSpeedGesture
                val steps = 5
                val stepDelay = 16L // ~one frame per step
                for (i in 1..steps) {
                  val t = i.toFloat() / steps
                  val intermediateSpeed = startSpeed + (targetSpeed - startSpeed) * t
                  MPVLib.setPropertyFloat("speed", intermediateSpeed)
                  if (i < steps) delay(stepDelay)
                }

                if (showDynamicSpeedOverlay) {
                  isDynamicSpeedControlActive = true
                  hasSwipedEnough = false
                  dynamicSpeedStartX = startPosition.x
                  dynamicSpeedStartValue = multipleSpeedGesture
                  lastAppliedSpeed = multipleSpeedGesture
                  viewModel.playerUpdate.update { PlayerUpdates.DynamicSpeedControl(multipleSpeedGesture, false) }
                } else {
                  viewModel.playerUpdate.update { PlayerUpdates.MultipleSpeed }
                }
              }
            }
          }

          var gestureType: String? = null

          do {
            val event = awaitPointerEvent()
            val pointerCount = event.changes.count { it.pressed }

            if (pointerCount == 1) {
              event.changes.forEach { change ->
                if (change.pressed) {
                  val currentPosition = change.position
                  val deltaX = currentPosition.x - startPosition.x
                  val deltaY = currentPosition.y - startPosition.y

                  // Determine gesture type based on initial drag direction
                  if (gestureType == null && (abs(deltaX) > 20f || abs(deltaY) > 20f)) {
                    // Cancel long press if drag started
                    longPressJob.cancel()

                    // Check if we're in long press mode with dynamic speed control
                    if (isLongPressing && isDynamicSpeedControlActive && showDynamicSpeedOverlay && abs(deltaX) > 10f) {
                      gestureType = "speed_control"
                    } else {
                      gestureType = if (abs(deltaX) > abs(deltaY) * 1.5f) {
                        "horizontal"
                      } else if (abs(deltaY) > abs(deltaX) * 1.5f) {
                        "vertical"
                      } else {
                        null
                      }
                    }

                    // Initialize gesture-specific state
                    when (gestureType) {
                      "speed_control" -> {
                        dynamicSpeedStartX = currentPosition.x
                        dynamicSpeedStartValue = MPVLib.getPropertyFloat("speed") ?: multipleSpeedGesture
                      }
                      "vertical" -> {
                        if ((brightnessGesture || volumeGesture) && !isLongPressing) {
                          isVerticalGestureActive = true
                          startingY = 0f
                          mpvVolumeStartingY = 0f
                          originalVolume = currentVolume
                          originalMPVVolume = currentMPVVolume
                          originalBrightness = currentBrightness
                          lastVolumeValue = currentVolume
                          lastMPVVolumeValue = currentMPVVolume ?: 100
                          lastBrightnessValue = currentBrightness
                        }
                      }
                    }
                  }

                  // Handle the appropriate gesture
                  when (gestureType) {
                    "speed_control" -> {
                      if (!showDynamicSpeedOverlay) return@forEach
                      if (isLongPressing && isDynamicSpeedControlActive && paused == false) {
                        change.consume()

                        val speedPresets = listOf(0.25f, 0.5f, 1.0f, 1.5f, 2.0f, 2.5f, 3.0f, 4.0f)
                        val screenWidth = size.width.toFloat()

                        val deltaX = currentPosition.x - dynamicSpeedStartX
                        val swipeDetectionThreshold = 10.dp.toPx()

                        if (!hasSwipedEnough && abs(deltaX) >= swipeDetectionThreshold) {
                          hasSwipedEnough = true
                          viewModel.playerUpdate.update { PlayerUpdates.DynamicSpeedControl(lastAppliedSpeed, true) }
                        }

                        if (hasSwipedEnough) {
                          val presetsRange = speedPresets.size - 1
                          val indexDelta = (deltaX / screenWidth) * presetsRange * 3.5f

                          val startIndex = speedPresets.indexOfFirst {
                            abs(it - dynamicSpeedStartValue) < 0.01f
                          }.takeIf { it >= 0 } ?: 4

                          val newIndex = (startIndex + indexDelta.toInt()).coerceIn(0, speedPresets.size - 1)
                          val newSpeed = speedPresets[newIndex]

                          if (abs(lastAppliedSpeed - newSpeed) > 0.01f) {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            lastAppliedSpeed = newSpeed
                            MPVLib.setPropertyFloat("speed", newSpeed)
                            viewModel.playerUpdate.update { PlayerUpdates.DynamicSpeedControl(newSpeed, true) }
                          }
                        }
                      }
                    }
                    "vertical" -> {
                      if ((brightnessGesture || volumeGesture) && !isLongPressing) {
                        val amount = currentPosition.y - startPosition.y

                        val changeVolume: () -> Unit = {
                          if (startingY == 0f) {
                            // Start from where the finger first touched so no movement is lost
                            startingY = startPosition.y
                            volumeStartLevel = viewModel.computeVolumeLevel()
                          }
                          viewModel.setVolumeLevel(
                            volumeStartLevel + (startingY - currentPosition.y) * volumeLevelPerPx,
                          )
                          viewModel.displayVolumeSlider()
                        }
                        val changeBrightness: () -> Unit = {
                          if (startingY == 0f) startingY = startPosition.y
                          val newBrightness = calculateNewVerticalGestureValue(
                            originalBrightness,
                            startingY,
                            currentPosition.y,
                            brightnessGestureSens,
                          )

                          if (abs(newBrightness - lastBrightnessValue) > 0.001f) {
                            viewModel.changeBrightnessTo(newBrightness)
                            lastBrightnessValue = newBrightness
                          }

                          viewModel.displayBrightnessSlider()
                        }

                        when {
                          volumeGesture && brightnessGesture -> {
                            if (swapVolumeAndBrightness) {
                              if (currentPosition.x > size.width / 2) changeBrightness() else changeVolume()
                            } else {
                              if (currentPosition.x < size.width / 2) changeBrightness() else changeVolume()
                            }
                          }
                          brightnessGesture -> changeBrightness()
                          volumeGesture -> changeVolume()
                          else -> {}
                        }

                        change.consume()
                      }
                    }
                  }
                }
              }
            } else if (pointerCount > 1) {
              // Multi-finger gesture detected
              longPressJob.cancel()
              if (gestureType != null) {
                when (gestureType) {
                  "vertical" -> {
                    if (brightnessGesture || volumeGesture) {
                      isVerticalGestureActive = false
                      startingY = 0f
                      lastVolumeValue = currentVolume
                      lastMPVVolumeValue = currentMPVVolume ?: 100
                      lastBrightnessValue = currentBrightness
                    }
                  }
                }
                gestureType = null
              }
              break
            }
          } while (event.changes.any { it.pressed })

          // Handle gesture end
          longPressJob.cancel()

          if (isLongPressing) {
            isLongPressing = false
            isDynamicSpeedControlActive = false
            hasSwipedEnough = false
            // Ramp speed back down incrementally to avoid audio filter stutter
            val currentSpeed = MPVLib.getPropertyFloat("speed") ?: multipleSpeedGesture
            val targetSpeed = originalSpeed
            val steps = 5
            val stepDelay = 16L
            coroutineScope.launch {
              for (i in 1..steps) {
                val t = i.toFloat() / steps
                val intermediateSpeed = currentSpeed + (targetSpeed - currentSpeed) * t
                MPVLib.setPropertyFloat("speed", intermediateSpeed)
                if (i < steps) delay(stepDelay)
              }
            }
            viewModel.playerUpdate.update { PlayerUpdates.None }
          }

          when (gestureType) {
            "vertical" -> {
              if (brightnessGesture || volumeGesture) {
                isVerticalGestureActive = false
                startingY = 0f
                lastVolumeValue = currentVolume
                lastMPVVolumeValue = currentMPVVolume ?: 100
                lastBrightnessValue = currentBrightness
              }
            }
          }
        }
      }
      .pointerInput(pinchToZoomGesture, panAndZoomEnabled, areControlsLocked, isVerticalGestureActive) {
        if (!pinchToZoomGesture || areControlsLocked || isVerticalGestureActive) return@pointerInput

        // Helper: get video display dimensions at 1x (how mpv fits the video to screen)
        fun videoDisplaySize(): Pair<Float, Float> {
          val sw = size.width.toFloat()
          val sh = size.height.toFloat()
          val va = MPVLib.getPropertyDouble("video-params/aspect")?.toFloat() ?: (sw / sh)
          val sa = sw / sh
          return if (va >= sa) Pair(sw, sw / va) else Pair(sh * va, sh)
        }

        // Helper: apply pan with EMA smoothing and bounds clamping
        fun applyPan(
          dx: Float, dy: Float, scale: Float,
          smoothState: FloatArray, // [smoothX, smoothY, initialized]
          smoothFactor: Float = 0.5f,
        ) {
          val sw = size.width.toFloat()
          val sh = size.height.toFloat()
          if (sw <= 0 || sh <= 0) return
          val (bw, bh) = videoDisplaySize()
          // 1 finger pixel = 1 video pixel
          val curX = MPVLib.getPropertyDouble("video-pan-x")?.toFloat() ?: 0f
          val curY = MPVLib.getPropertyDouble("video-pan-y")?.toFloat() ?: 0f
          val targetX = curX + dx / (bw * scale)
          val targetY = curY + dy / (bh * scale)
          // Initialize smoothing on first call
          if (smoothState[2] == 0f) { smoothState[0] = targetX; smoothState[1] = targetY; smoothState[2] = 1f }
          smoothState[0] += (targetX - smoothState[0]) * smoothFactor
          smoothState[1] += (targetY - smoothState[1]) * smoothFactor
          // Bounds: video edge can't go past screen edge
          val maxPan = ((scale - 1f) / (2f * scale)).coerceAtLeast(0f)
          viewModel.setVideoPan(
            smoothState[0].coerceIn(-maxPan, maxPan),
            smoothState[1].coerceIn(-maxPan, maxPan),
          )
        }

        awaitEachGesture {
          var zoom = 0f
          var gestureStarted = false
          var prevDist = 0f
          var prevMidX = 0f
          var prevMidY = 0f
          val panSmooth = floatArrayOf(0f, 0f, 0f) // smoothX, smoothY, initialized

          awaitFirstDown(requireUnconsumed = false)

          do {
            val event = awaitPointerEvent()
            val pressed = event.changes.filter { it.pressed }

            if (pressed.size == 2) {
              val p1 = pressed[0].position
              val p2 = pressed[1].position
              val dx = p2.x - p1.x
              val dy = p2.y - p1.y
              val dist = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
              val midX = (p1.x + p2.x) / 2f
              val midY = (p1.y + p2.y) / 2f

              if (prevDist == 0f) {
                // First frame — capture baseline
                prevDist = dist
                zoom = MPVLib.getPropertyDouble("video-zoom")?.toFloat() ?: 0f
                prevMidX = midX
                prevMidY = midY
              } else {
                // Activate on significant pinch movement
                if (!gestureStarted && abs(dist - prevDist) > 5f) {
                  gestureStarted = true
                  viewModel.playerUpdate.update { PlayerUpdates.VideoZoom }
                }

                if (gestureStarted) {
                  // Per-frame zoom: small delta from previous distance → naturally smooth
                  val zoomDelta = ln((dist / prevDist).toDouble()).toFloat() * 1.2f
                  zoom = (zoom + zoomDelta).coerceIn(-1f, 3f)
                  viewModel.setVideoZoom(zoom)

                  // Simultaneous pan while pinching
                  if (panAndZoomEnabled) {
                    applyPan(midX - prevMidX, midY - prevMidY, 2f.pow(zoom), panSmooth)
                  }
                }

                prevDist = dist
                prevMidX = midX
                prevMidY = midY
              }

              pressed.forEach { it.consume() }
            } else if (pressed.size < 2 && prevDist != 0f) {
              break
            }
          } while (event.changes.any { it.pressed })
        }
      }
      // Single-finger pan (only when Pan & Zoom enabled and zoomed in)
      .pointerInput(panAndZoomEnabled, pinchToZoomGesture, areControlsLocked, isVerticalGestureActive) {
        if (!panAndZoomEnabled || !pinchToZoomGesture || areControlsLocked || isVerticalGestureActive) return@pointerInput

        awaitEachGesture {
          val down = awaitFirstDown(requireUnconsumed = false)
          var panning = false
          var prevX = down.position.x
          var prevY = down.position.y
          val startX = prevX
          val startY = prevY
          val panSmooth = floatArrayOf(0f, 0f, 0f)

          // Helper: get video display dimensions at 1x
          fun videoDisplaySize(): Pair<Float, Float> {
            val sw = size.width.toFloat()
            val sh = size.height.toFloat()
            val va = MPVLib.getPropertyDouble("video-params/aspect")?.toFloat() ?: (sw / sh)
            val sa = sw / sh
            return if (va >= sa) Pair(sw, sw / va) else Pair(sh * va, sh)
          }

          do {
            val event = awaitPointerEvent()
            val pressed = event.changes.filter { it.pressed }

            if (pressed.size == 1) {
              val change = pressed[0]
              val zoom = MPVLib.getPropertyDouble("video-zoom")?.toFloat() ?: 0f
              if (zoom <= 0f) { continue }

              val pos = change.position

              // Activate after 20px drag threshold
              if (!panning) {
                val d = sqrt((pos.x - startX).let { it * it } + (pos.y - startY).let { it * it })
                if (d > 20f) { panning = true; prevX = pos.x; prevY = pos.y }
              }

              if (panning) {
                val sw = size.width.toFloat()
                val sh = size.height.toFloat()
                if (sw > 0 && sh > 0) {
                  val scale = 2f.pow(zoom)
                  val (bw, bh) = videoDisplaySize()
                  val curX = MPVLib.getPropertyDouble("video-pan-x")?.toFloat() ?: 0f
                  val curY = MPVLib.getPropertyDouble("video-pan-y")?.toFloat() ?: 0f
                  val targetX = curX + (pos.x - prevX) / (bw * scale)
                  val targetY = curY + (pos.y - prevY) / (bh * scale)
                  // Initialize smoothing on first pan frame
                  if (panSmooth[2] == 0f) { panSmooth[0] = targetX; panSmooth[1] = targetY; panSmooth[2] = 1f }
                  panSmooth[0] += (targetX - panSmooth[0]) * 0.5f
                  panSmooth[1] += (targetY - panSmooth[1]) * 0.5f
                  val maxPan = ((scale - 1f) / (2f * scale)).coerceAtLeast(0f)
                  viewModel.setVideoPan(
                    panSmooth[0].coerceIn(-maxPan, maxPan),
                    panSmooth[1].coerceIn(-maxPan, maxPan),
                  )
                  prevX = pos.x
                  prevY = pos.y
                }
                change.consume()
              }
            } else if (pressed.size > 1) {
              break
            }
          } while (event.changes.any { it.pressed })
        }
      }
      .pointerInput(horizontalSwipeToSeek, areControlsLocked, gesturePreferences, isVerticalGestureActive) {
        if (!horizontalSwipeToSeek || areControlsLocked || isVerticalGestureActive) return@pointerInput

        awaitEachGesture {
          val down = awaitFirstDown(requireUnconsumed = false)
          val startPosition = down.position
          val startTime = System.currentTimeMillis()
          
          var gestureType: String? = null
          var hasStartedSeeking = false
          var initialVideoPosition = 0f
          var wasPlayerAlreadyPaused = false
          // Use the sensitivity preference instead of hardcoded value
          val seekSensitivity = horizontalSwipeSensitivity
          
          do {
            val event = awaitPointerEvent()
            val pointerCount = event.changes.count { it.pressed }

            if (pointerCount == 1) {
              event.changes.forEach { change ->
                if (change.pressed) {
                  val currentPosition = change.position
                  val deltaX = currentPosition.x - startPosition.x
                  val deltaY = currentPosition.y - startPosition.y
                  val timeSinceStart = System.currentTimeMillis() - startTime

                  // Only activate if this is clearly a horizontal gesture
                  // and not conflicting with other gestures
                  if (gestureType == null && 
                      abs(deltaX) > 30f && 
                      abs(deltaX) > abs(deltaY) * 2f && // Must be strongly horizontal
                      timeSinceStart > 100L && // Avoid conflicts with double-tap
                      !isLongPressing && // Don't conflict with long press
                      !isDynamicSpeedControlActive && // Don't conflict with speed control
                      panelShown == Panels.None) { // Only when no panels are shown
                    
                    gestureType = "horizontal_seek"
                    hasStartedSeeking = true
                    initialVideoPosition = position?.toFloat() ?: 0f
                    
                    // Pause before seeking to prevent decoder stalls
                    wasPlayerAlreadyPaused = paused ?: false
                    if (!wasPlayerAlreadyPaused) {
                      viewModel.pause()
                    }
                    
                    // Show seekbar and start seeking mode (same as seekbar scrubbing)
                    viewModel.showSeekBar()
                    change.consume()
                  }

                  if (gestureType == "horizontal_seek" && hasStartedSeeking) {
                    // Calculate seek amount based on horizontal movement
                    val seekAmount = deltaX * seekSensitivity
                    val targetPosition = (initialVideoPosition + seekAmount).coerceAtLeast(0f)
                    val maxDuration = duration?.toFloat() ?: 0f
                    val clampedPosition = targetPosition.coerceAtMost(maxDuration)
                    
                    // Use the same seeking mechanism as seekbar scrubbing
                    // This will update the seekbar position and provide live preview
                    viewModel.seekTo(clampedPosition.toInt())
                    
                    // Format and display time position updates
                    val currentPos = clampedPosition.toInt()
                    val seekDelta = (clampedPosition - initialVideoPosition).toInt()
                    
                    val currentTimeStr = formatSeekTime(currentPos)
                    
                    // Format seek delta with +/- prefix
                    val deltaStr = if (seekDelta >= 0) {
                      "+${formatSeekTime(seekDelta)}"
                    } else {
                      "-${formatSeekTime(-seekDelta)}"
                    }
                    
                    // Use PlayerUpdates system like zoom updates
                    viewModel.playerUpdate.update { 
                      PlayerUpdates.HorizontalSeek(currentTimeStr, deltaStr)
                    }
                    
                    change.consume()
                  }
                }
              }
            } else if (pointerCount > 1) {
              // Multi-finger detected, cancel horizontal seek
              if (hasStartedSeeking) {
                hasStartedSeeking = false
                // Clean up seeking state without showing controls
                viewModel.playerUpdate.update { PlayerUpdates.None }
                viewModel.hideSeekBar()
              }
              break
            }
          } while (event.changes.any { it.pressed })

          // Apply the final seek when gesture ends
          if (hasStartedSeeking) {
            // Unpause if it wasn't paused before seeking
            if (!wasPlayerAlreadyPaused) {
              viewModel.unpause()
            }
            
            // Clear the horizontal seek update and hide seekbar after a short delay
            coroutineScope.launch {
              delay(300)
              viewModel.playerUpdate.update { PlayerUpdates.None }
              viewModel.hideSeekBar()
            }
          }
        }
      },
  )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DoubleTapToSeekOvals(
  amount: Int,
  text: String?,
  showOvals: Boolean,
  showSeekIcon: Boolean,
  showSeekTime: Boolean,
  interactionSource: MutableInteractionSource,
  modifier: Modifier = Modifier,
) {
  val gesturePreferences = koinInject<GesturePreferences>()
  val doubleTapSeekAreaWidth by gesturePreferences.doubleTapSeekAreaWidth.collectAsState()
  val seekAreaFraction = doubleTapSeekAreaWidth / 100f
  
  val alpha by animateFloatAsState(if (amount == 0) 0f else 0.2f, label = "double_tap_animation_alpha")

  // Scale animation for text
  var scaleTarget by remember { mutableStateOf(1f) }
  val scale by animateFloatAsState(
      targetValue = scaleTarget,
      animationSpec = tween(durationMillis = 150),
      label = "text_scale"
  )
  
  LaunchedEffect(amount) {
      if (amount != 0) {
          scaleTarget = 1.2f
          delay(100)
          scaleTarget = 1f
      } else {
        scaleTarget = 1f
      }
  }

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = if (amount > 0) Alignment.CenterEnd else Alignment.CenterStart,
  ) {
    CompositionLocalProvider(
      LocalRippleConfiguration provides playerRippleConfiguration,
    ) {
      if (amount != 0) {
        Box(
          modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth(seekAreaFraction),
          contentAlignment = Alignment.Center,
        ) {
          if (showOvals) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .clip(if (amount > 0) RightSideOvalShape else LeftSideOvalShape)
                .background(Color.White.copy(alpha))
                .indication(interactionSource, ripple()),
            )
          }
          if (showSeekIcon || showSeekTime) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (amount < 0) {
                    CombiningChevronsAnimation(isRight = false, trigger = amount)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "- ${abs(amount)}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = Color.White,
                        modifier = Modifier.scale(scale)
                    )
                } else {
                    Text(
                        text = "+ ${abs(amount)}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = Color.White,
                        modifier = Modifier.scale(scale)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    CombiningChevronsAnimation(isRight = true, trigger = amount)
                }
            }
          }
        }
      }
    }
  }
}

fun calculateNewVerticalGestureValue(originalValue: Int, startingY: Float, newY: Float, sensitivity: Float): Int {
  return originalValue + ((startingY - newY) * sensitivity).toInt()
}

fun calculateNewVerticalGestureValue(originalValue: Float, startingY: Float, newY: Float, sensitivity: Float): Float {
  return originalValue + ((startingY - newY) * sensitivity)
}

private fun formatSeekTime(seconds: Int): String {
  val absSeconds = kotlin.math.abs(seconds)
  val hours = absSeconds / 3600
  val minutes = (absSeconds % 3600) / 60
  val secs = absSeconds % 60
  return if (hours > 0) {
    String.format("%d:%02d:%02d", hours, minutes, secs)
  } else {
    String.format("%02d:%02d", minutes, secs)
  }
}

@Composable
fun CombiningChevronsAnimation(
    isRight: Boolean,
    trigger: Int,
    modifier: Modifier = Modifier
) {
    // List of active animations (unique IDs)
    val animations = remember { mutableStateListOf<Long>() }

    // Fire a new animation whenever trigger changes
    LaunchedEffect(trigger) {
        animations.add(System.nanoTime())
    }

    Row(modifier = modifier) {
        Box {
             // Static Chevron
              Icon(
                imageVector = if (isRight) Icons.AutoMirrored.Filled.KeyboardArrowRight else Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
            
            // Render active moving chevrons
            animations.forEach { animId ->
                key(animId) {
                    MovingChevron(
                        isRight = isRight,
                        onFinished = { animations.remove(animId) }
                    )
                }
            }
        }
    }
}

@Composable
fun MovingChevron(
    isRight: Boolean,
    onFinished: () -> Unit
) {
    val progress = remember { Animatable(0f) }
    
    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(250, easing = LinearEasing)
        )
        onFinished()
    }
    
    val startOffset = if (isRight) -15f else 15f
    val currentOffset = startOffset * (1f - progress.value)
    val alpha = 1f - progress.value
    
    Icon(
        imageVector = if (isRight) Icons.AutoMirrored.Filled.KeyboardArrowRight else Icons.AutoMirrored.Filled.KeyboardArrowLeft,
        contentDescription = null,
        tint = Color.White,
        modifier = Modifier
            .size(48.dp)
            .alpha(alpha)
            .layout { measurable, constraints ->
                val placeable = measurable.measure(constraints)
                layout(placeable.width, placeable.height) {
                    placeable.placeRelative(x = currentOffset.dp.roundToPx(), y = 0)
                }
            } 
    )
}
